/* eslint-disable no-console */
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcrypt';

const prisma = new PrismaClient();

const TENANT_ID = 1;
const ORGANIZATION_ID = 1;

// ---------------------------------------------------------------------------
// Static role/permission matrix for Phase 1. In Phase 2 this becomes editable
// via an admin UI; for now it is the single source of truth for seeding.
// ---------------------------------------------------------------------------

const PERMISSIONS = [
  // Users / Admin
  { code: 'users.manage', module: 'users', description: 'Create, update, deactivate users' },

  // Master Data
  { code: 'masterdata.view', module: 'master-data', description: 'View statuses, lift types, service types' },
  { code: 'masterdata.manage', module: 'master-data', description: 'Manage statuses, lift types, service types' },

  // Customers / Sites / Lifts
  { code: 'customer.view', module: 'customer', description: 'View customers and sites' },
  { code: 'customer.manage', module: 'customer', description: 'Create/update customers and sites' },
  { code: 'lift.view', module: 'lift', description: 'View lift records' },
  { code: 'lift.manage', module: 'lift', description: 'Create/update lift records' },

  // Installation
  { code: 'installation.view', module: 'installation', description: 'View installation projects' },
  { code: 'installation.create', module: 'installation', description: 'Create installation projects' },
  { code: 'installation.update', module: 'installation', description: 'Update installation projects/tasks' },
  { code: 'installation.assign', module: 'installation', description: 'Assign engineers/technicians to tasks' },
  { code: 'installation.signoff', module: 'installation', description: 'Sign off installation milestones' },

  // AMC
  { code: 'amc.view', module: 'amc', description: 'View AMC contracts and visits' },
  { code: 'amc.create', module: 'amc', description: 'Create AMC contracts' },
  { code: 'amc.update', module: 'amc', description: 'Update AMC contracts/schedules' },
  { code: 'amc.assign', module: 'amc', description: 'Assign technicians to visits' },
  { code: 'amc.visit.log', module: 'amc', description: 'Log AMC visit findings/actions' }
] as const;

const ROLE_PERMISSIONS: Record<string, string[]> = {
  ADMIN: PERMISSIONS.map((p) => p.code), // Admin gets everything
  MANAGER: [
    'masterdata.view',
    'customer.view',
    'customer.manage',
    'lift.view',
    'lift.manage',
    'installation.view',
    'installation.create',
    'installation.update',
    'installation.assign',
    'installation.signoff',
    'amc.view',
    'amc.create',
    'amc.update',
    'amc.assign'
  ],
  ENGINEER: [
    'masterdata.view',
    'customer.view',
    'lift.view',
    'installation.view',
    'installation.update',
    'installation.signoff'
  ],
  TECHNICIAN: ['masterdata.view', 'lift.view', 'installation.view', 'amc.view', 'amc.visit.log']
};

const STATUS_SEED: Array<{ entityType: string; code: string; label: string; color?: string; sortOrder: number }> = [
  // INSTALLATION_PROJECT
  { entityType: 'INSTALLATION_PROJECT', code: 'DRAFT', label: 'Draft', color: 'slate', sortOrder: 1 },
  { entityType: 'INSTALLATION_PROJECT', code: 'SCHEDULED', label: 'Scheduled', color: 'blue', sortOrder: 2 },
  { entityType: 'INSTALLATION_PROJECT', code: 'IN_PROGRESS', label: 'In Progress', color: 'amber', sortOrder: 3 },
  { entityType: 'INSTALLATION_PROJECT', code: 'ON_HOLD', label: 'On Hold', color: 'orange', sortOrder: 4 },
  { entityType: 'INSTALLATION_PROJECT', code: 'COMPLETED', label: 'Completed', color: 'green', sortOrder: 5 },
  { entityType: 'INSTALLATION_PROJECT', code: 'CANCELLED', label: 'Cancelled', color: 'red', sortOrder: 6 },

  // INSTALLATION_TASK
  { entityType: 'INSTALLATION_TASK', code: 'PENDING', label: 'Pending', color: 'slate', sortOrder: 1 },
  { entityType: 'INSTALLATION_TASK', code: 'IN_PROGRESS', label: 'In Progress', color: 'amber', sortOrder: 2 },
  { entityType: 'INSTALLATION_TASK', code: 'BLOCKED', label: 'Blocked', color: 'red', sortOrder: 3 },
  { entityType: 'INSTALLATION_TASK', code: 'COMPLETED', label: 'Completed', color: 'green', sortOrder: 4 },

  // AMC_CONTRACT
  { entityType: 'AMC_CONTRACT', code: 'DRAFT', label: 'Draft', color: 'slate', sortOrder: 1 },
  { entityType: 'AMC_CONTRACT', code: 'ACTIVE', label: 'Active', color: 'green', sortOrder: 2 },
  { entityType: 'AMC_CONTRACT', code: 'PENDING_RENEWAL', label: 'Pending Renewal', color: 'amber', sortOrder: 3 },
  { entityType: 'AMC_CONTRACT', code: 'EXPIRED', label: 'Expired', color: 'red', sortOrder: 4 },
  { entityType: 'AMC_CONTRACT', code: 'CANCELLED', label: 'Cancelled', color: 'red', sortOrder: 5 },

  // AMC_SCHEDULE
  { entityType: 'AMC_SCHEDULE', code: 'PLANNED', label: 'Planned', color: 'blue', sortOrder: 1 },
  { entityType: 'AMC_SCHEDULE', code: 'COMPLETED', label: 'Completed', color: 'green', sortOrder: 2 },
  { entityType: 'AMC_SCHEDULE', code: 'MISSED', label: 'Missed', color: 'red', sortOrder: 3 },
  { entityType: 'AMC_SCHEDULE', code: 'RESCHEDULED', label: 'Rescheduled', color: 'amber', sortOrder: 4 },

  // AMC_VISIT
  { entityType: 'AMC_VISIT', code: 'SCHEDULED', label: 'Scheduled', color: 'blue', sortOrder: 1 },
  { entityType: 'AMC_VISIT', code: 'IN_PROGRESS', label: 'In Progress', color: 'amber', sortOrder: 2 },
  { entityType: 'AMC_VISIT', code: 'COMPLETED', label: 'Completed', color: 'green', sortOrder: 3 },
  { entityType: 'AMC_VISIT', code: 'CANCELLED', label: 'Cancelled', color: 'red', sortOrder: 4 },

  // LIFT
  { entityType: 'LIFT', code: 'INSTALLED', label: 'Installed', color: 'green', sortOrder: 1 },
  { entityType: 'LIFT', code: 'UNDER_MAINTENANCE', label: 'Under Maintenance', color: 'amber', sortOrder: 2 },
  { entityType: 'LIFT', code: 'DECOMMISSIONED', label: 'Decommissioned', color: 'red', sortOrder: 3 }
];

const LIFT_TYPES = [
  { code: 'PASSENGER', name: 'Passenger Lift' },
  { code: 'FREIGHT', name: 'Freight / Goods Lift' },
  { code: 'HOSPITAL', name: 'Hospital Lift' },
  { code: 'PANORAMIC', name: 'Panoramic / Glass Lift' },
  { code: 'HOME', name: 'Home / Residential Lift' }
];

const SERVICE_TYPES = [
  { code: 'PREVENTIVE', name: 'Preventive Maintenance' },
  { code: 'BREAKDOWN', name: 'Breakdown / Corrective Maintenance' },
  { code: 'EMERGENCY', name: 'Emergency Callout' },
  { code: 'INSPECTION', name: 'Inspection / Statutory Audit' }
];

const ROLE_DEFS = [
  { code: 'ADMIN', name: 'Admin' },
  { code: 'MANAGER', name: 'Manager' },
  { code: 'ENGINEER', name: 'Engineer' },
  { code: 'TECHNICIAN', name: 'Technician' }
];

async function main() {
  console.log('🌱 Seeding Lift SaaS Phase 1 data...');

  // --- Tenant / Organization -------------------------------------------------
  await prisma.tenant.upsert({
    where: { id: TENANT_ID },
    update: {},
    create: { id: TENANT_ID, name: 'Default Tenant', slug: 'default' }
  });

  await prisma.organization.upsert({
    where: { id: ORGANIZATION_ID },
    update: {},
    create: { id: ORGANIZATION_ID, tenantId: TENANT_ID, name: 'Default Organization' }
  });
  console.log('  ✓ Tenant + Organization');

  // --- Permissions -------------------------------------------------------------
  for (const perm of PERMISSIONS) {
    await prisma.permission.upsert({
      where: { code: perm.code },
      update: { module: perm.module, description: perm.description },
      create: perm
    });
  }
  console.log(`  ✓ ${PERMISSIONS.length} permissions`);

  // --- Roles + RolePermission mapping -------------------------------------------
  const roleIdByCode: Record<string, number> = {};
  for (const roleDef of ROLE_DEFS) {
    const role = await prisma.role.upsert({
      where: { tenantId_code: { tenantId: TENANT_ID, code: roleDef.code } },
      update: { name: roleDef.name },
      create: { tenantId: TENANT_ID, code: roleDef.code, name: roleDef.name }
    });
    roleIdByCode[roleDef.code] = role.id;
  }

  const allPermissions = await prisma.permission.findMany();
  const permissionIdByCode = new Map(allPermissions.map((p) => [p.code, p.id]));

  for (const [roleCode, permCodes] of Object.entries(ROLE_PERMISSIONS)) {
    const roleId = roleIdByCode[roleCode];
    for (const permCode of permCodes) {
      const permissionId = permissionIdByCode.get(permCode);
      if (!permissionId) continue;
      await prisma.rolePermission.upsert({
        where: { roleId_permissionId: { roleId, permissionId } },
        update: {},
        create: { roleId, permissionId }
      });
    }
  }
  console.log('  ✓ Roles + role-permission matrix');

  // --- Master Data: Statuses ------------------------------------------------
  for (const status of STATUS_SEED) {
    await prisma.status.upsert({
      where: {
        tenantId_entityType_code: { tenantId: TENANT_ID, entityType: status.entityType, code: status.code }
      },
      update: { label: status.label, color: status.color, sortOrder: status.sortOrder },
      create: { tenantId: TENANT_ID, ...status }
    });
  }
  console.log(`  ✓ ${STATUS_SEED.length} status rows across all entity types`);

  // --- Master Data: Lift Types -----------------------------------------------
  for (const lt of LIFT_TYPES) {
    await prisma.liftType.upsert({
      where: { tenantId_code: { tenantId: TENANT_ID, code: lt.code } },
      update: { name: lt.name },
      create: { tenantId: TENANT_ID, ...lt }
    });
  }
  console.log(`  ✓ ${LIFT_TYPES.length} lift types`);

  // --- Master Data: Service Types ---------------------------------------------
  for (const st of SERVICE_TYPES) {
    await prisma.serviceType.upsert({
      where: { tenantId_code: { tenantId: TENANT_ID, code: st.code } },
      update: { name: st.name },
      create: { tenantId: TENANT_ID, ...st }
    });
  }
  console.log(`  ✓ ${SERVICE_TYPES.length} service types`);

  // --- Bootstrap Admin User ---------------------------------------------------
  const adminEmail = 'admin@liftsaas.example.com';
  const tempPassword = 'Admin@12345'; // CHANGE IMMEDIATELY after first login
  const passwordHash = await bcrypt.hash(tempPassword, 10);

  await prisma.user.upsert({
    where: { tenantId_email: { tenantId: TENANT_ID, email: adminEmail } },
    update: {},
    create: {
      tenantId: TENANT_ID,
      organizationId: ORGANIZATION_ID,
      roleId: roleIdByCode.ADMIN,
      email: adminEmail,
      passwordHash,
      firstName: 'System',
      lastName: 'Admin'
    }
  });
  console.log(`  ✓ Bootstrap admin user (${adminEmail} / ${tempPassword} — change immediately)`);

  console.log('✅ Seed complete.');
}

main()
  .catch((err) => {
    console.error('❌ Seed failed:', err);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
