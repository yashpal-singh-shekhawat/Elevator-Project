import { Request, Response } from 'express';
import { AuthService } from './auth.service';
import { LoginInput } from './auth.validation';
import { asyncHandler } from '@common/utils/async-handler';
import { ApiResponse } from '@common/responses/api-response';
import { UnauthorizedError } from '@common/errors';
import { env } from '@config/env';
import { refreshTokenCookieOptions, clearRefreshTokenCookieOptions } from '@common/utils/cookie-options';

export class AuthController {
  constructor(private readonly authService: AuthService) {}

  login = asyncHandler(async (req: Request, res: Response) => {
    const { email, password } = req.body as LoginInput;

    const result = await this.authService.login(req.tenantContext, email, password, {
      ipAddress: req.ip,
      userAgent: req.header('user-agent')
    });

    res.cookie(env.REFRESH_TOKEN_COOKIE_NAME, result.refreshToken, refreshTokenCookieOptions());

    await req.audit.log({ entityType: 'USER', entityId: result.user.id, action: 'UPDATE' });

    ApiResponse.success(res, { accessToken: result.accessToken, user: result.user });
  });

  refresh = asyncHandler(async (req: Request, res: Response) => {
    const presentedToken = req.cookies?.[env.REFRESH_TOKEN_COOKIE_NAME];
    if (!presentedToken) {
      throw new UnauthorizedError('No refresh token provided');
    }

    const result = await this.authService.refresh(req.tenantContext, presentedToken, {
      ipAddress: req.ip,
      userAgent: req.header('user-agent')
    });

    res.cookie(env.REFRESH_TOKEN_COOKIE_NAME, result.refreshToken, refreshTokenCookieOptions());

    ApiResponse.success(res, { accessToken: result.accessToken, user: result.user });
  });

  logout = asyncHandler(async (req: Request, res: Response) => {
    const presentedToken = req.cookies?.[env.REFRESH_TOKEN_COOKIE_NAME];
    await this.authService.logout(presentedToken);
    res.clearCookie(env.REFRESH_TOKEN_COOKIE_NAME, clearRefreshTokenCookieOptions());
    ApiResponse.noContent(res);
  });

  me = asyncHandler(async (req: Request, res: Response) => {
    // authenticate() middleware guarantees req.user is set on this route.
    const user = await this.authService.getCurrentUser(req.tenantContext, req.user!.id);
    ApiResponse.success(res, user);
  });
}
