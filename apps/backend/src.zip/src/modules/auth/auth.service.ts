import { v4 as uuidv4 } from 'uuid';
import { AuthRepository, UserWithRole } from './auth.repository';
import { comparePassword } from '@common/utils/hash';
import { sha256 } from '@common/utils/token-hash';
import { addDuration } from '@common/utils/duration';
import { signAccessToken, signRefreshToken, verifyRefreshToken, AccessTokenPayload } from '@common/utils/jwt';
import { UnauthorizedError } from '@common/errors';
import { TenantContext } from '@common/types/tenant-context';
import { env } from '@config/env';

export interface LoginResult {
  accessToken: string;
  refreshToken: string;
  user: SafeUser;
}

export interface SafeUser {
  id: number;
  email: string;
  firstName: string;
  lastName: string;
  roleId: number;
  roleCode: string;
  roleName: string;
  permissions: string[];
}

interface RequestMeta {
  ipAddress?: string;
  userAgent?: string;
}

function toSafeUser(user: UserWithRole): SafeUser {
  return {
    id: user.id,
    email: user.email,
    firstName: user.firstName,
    lastName: user.lastName,
    roleId: user.roleId,
    roleCode: user.role.code,
    roleName: user.role.name,
    permissions: user.role.rolePermissions.map((rp) => rp.permission.code)
  };
}

function toAccessTokenPayload(tenant: TenantContext, user: UserWithRole): AccessTokenPayload {
  return {
    sub: user.id,
    tenantId: tenant.tenantId,
    organizationId: tenant.organizationId,
    roleId: user.roleId,
    roleCode: user.role.code,
    email: user.email,
    permissions: user.role.rolePermissions.map((rp) => rp.permission.code)
  };
}

export class AuthService {
  constructor(private readonly authRepository: AuthRepository) {}

  async login(tenant: TenantContext, email: string, password: string, meta: RequestMeta): Promise<LoginResult> {
    const user = await this.authRepository.findActiveUserByEmail(tenant, email);

    // Deliberately generic message — do not reveal whether the email exists.
    if (!user) {
      throw new UnauthorizedError('Invalid email or password');
    }

    const passwordMatches = await comparePassword(password, user.passwordHash);
    if (!passwordMatches) {
      throw new UnauthorizedError('Invalid email or password');
    }

    const accessToken = signAccessToken(toAccessTokenPayload(tenant, user));
    const refreshToken = await this.issueRefreshToken(user.id, meta);

    await this.authRepository.touchLastLogin(user.id);

    return { accessToken, refreshToken, user: toSafeUser(user) };
  }

  /**
   * Verifies + rotates a refresh token: the presented token is revoked and a
   * brand new one is issued, so a stolen-but-unused token can only ever be
   * used once before its reuse is detectable (the old hash is gone).
   */
  async refresh(tenant: TenantContext, presentedToken: string, meta: RequestMeta): Promise<LoginResult> {
    let userId: number;
    try {
      ({ sub: userId } = verifyRefreshToken(presentedToken));
    } catch {
      throw new UnauthorizedError('Invalid or expired refresh token');
    }

    const tokenHash = sha256(presentedToken);
    const storedToken = await this.authRepository.findValidRefreshTokenByHash(tokenHash);

    if (!storedToken || storedToken.userId !== userId) {
      throw new UnauthorizedError('Refresh token is invalid, expired, or has already been used');
    }

    const user = await this.authRepository.findActiveUserById(tenant, userId);
    if (!user) {
      throw new UnauthorizedError('User is no longer active');
    }

    // Rotate: revoke the presented token, issue a new one.
    await this.authRepository.revokeRefreshTokenById(storedToken.id);
    const accessToken = signAccessToken(toAccessTokenPayload(tenant, user));
    const refreshToken = await this.issueRefreshToken(user.id, meta);

    return { accessToken, refreshToken, user: toSafeUser(user) };
  }

  async logout(presentedToken: string | undefined): Promise<void> {
    if (!presentedToken) return;
    const tokenHash = sha256(presentedToken);
    await this.authRepository.revokeRefreshTokenByHash(tokenHash);
  }

  async getCurrentUser(tenant: TenantContext, userId: number): Promise<SafeUser> {
    const user = await this.authRepository.findActiveUserById(tenant, userId);
    if (!user) {
      throw new UnauthorizedError('User is no longer active');
    }
    return toSafeUser(user);
  }

  private async issueRefreshToken(userId: number, meta: RequestMeta): Promise<string> {
    const jti = uuidv4();
    const token = signRefreshToken({ sub: userId, jti });
    const tokenHash = sha256(token);
    const expiresAt = addDuration(new Date(), env.JWT_REFRESH_EXPIRES_IN);

    await this.authRepository.createRefreshToken({
      userId,
      tokenHash,
      expiresAt,
      userAgent: meta.userAgent,
      ipAddress: meta.ipAddress
    });

    return token;
  }
}
