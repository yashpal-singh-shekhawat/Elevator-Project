import { Prisma, PrismaClient } from '@prisma/client';
import { TenantContext } from '@common/types/tenant-context';

export const userWithRoleInclude = {
  role: {
    include: {
      rolePermissions: { include: { permission: true } }
    }
  }
} as const;

export type UserWithRole = Prisma.UserGetPayload<{ include: typeof userWithRoleInclude }>;

export class AuthRepository {
  constructor(private readonly prisma: PrismaClient) {}

  findActiveUserByEmail(tenant: TenantContext, email: string) {
    return this.prisma.user.findFirst({
      where: { tenantId: tenant.tenantId, email, isActive: true, deletedAt: null },
      include: userWithRoleInclude
    });
  }

  findActiveUserById(tenant: TenantContext, id: number) {
    return this.prisma.user.findFirst({
      where: { id, tenantId: tenant.tenantId, isActive: true, deletedAt: null },
      include: userWithRoleInclude
    });
  }

  touchLastLogin(userId: number) {
    return this.prisma.user.update({
      where: { id: userId },
      data: { lastLoginAt: new Date() }
    });
  }

  createRefreshToken(data: {
    userId: number;
    tokenHash: string;
    expiresAt: Date;
    userAgent?: string;
    ipAddress?: string;
  }) {
    return this.prisma.refreshToken.create({ data });
  }

  findValidRefreshTokenByHash(tokenHash: string) {
    return this.prisma.refreshToken.findFirst({
      where: { tokenHash, revokedAt: null, expiresAt: { gt: new Date() } }
    });
  }

  revokeRefreshTokenById(id: number) {
    return this.prisma.refreshToken.update({
      where: { id },
      data: { revokedAt: new Date() }
    });
  }

  revokeRefreshTokenByHash(tokenHash: string) {
    return this.prisma.refreshToken.updateMany({
      where: { tokenHash, revokedAt: null },
      data: { revokedAt: new Date() }
    });
  }

  revokeAllTokensForUser(userId: number) {
    return this.prisma.refreshToken.updateMany({
      where: { userId, revokedAt: null },
      data: { revokedAt: new Date() }
    });
  }
}
