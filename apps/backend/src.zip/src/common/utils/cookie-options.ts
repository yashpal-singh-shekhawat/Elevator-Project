import { CookieOptions } from 'express';
import { env } from '@config/env';
import { parseDurationMs } from './duration';

// Scoped to /auth so the refresh token cookie is never sent on ordinary API
// requests — only to the endpoints that actually need it (refresh, logout).
export function refreshTokenCookieOptions(): CookieOptions {
  return {
    httpOnly: true,
    secure: env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: `${env.API_PREFIX}/auth`,
    maxAge: parseDurationMs(env.JWT_REFRESH_EXPIRES_IN)
  };
}

export function clearRefreshTokenCookieOptions(): CookieOptions {
  const { maxAge: _maxAge, ...rest } = refreshTokenCookieOptions();
  return rest;
}
