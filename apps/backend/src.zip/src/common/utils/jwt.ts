import jwt, { SignOptions } from 'jsonwebtoken';
import { env } from '@config/env';

export interface AccessTokenPayload {
  sub: number; // userId
  tenantId: number;
  organizationId: number;
  roleId: number;
  roleCode: string;
  email: string;
  permissions: string[];
}

export interface RefreshTokenPayload {
  sub: number; // userId
  jti: string; // unique token id, also used as the DB lookup correlation key
}

export function signAccessToken(payload: AccessTokenPayload): string {
  return jwt.sign(payload, env.JWT_ACCESS_SECRET, {
    expiresIn: env.JWT_ACCESS_EXPIRES_IN
  } as SignOptions);
}

export function verifyAccessToken(token: string): AccessTokenPayload {
  return jwt.verify(token, env.JWT_ACCESS_SECRET) as AccessTokenPayload;
}

export function signRefreshToken(payload: RefreshTokenPayload): string {
  return jwt.sign(payload, env.JWT_REFRESH_SECRET, {
    expiresIn: env.JWT_REFRESH_EXPIRES_IN
  } as SignOptions);
}

export function verifyRefreshToken(token: string): RefreshTokenPayload {
  return jwt.verify(token, env.JWT_REFRESH_SECRET) as RefreshTokenPayload;
}
