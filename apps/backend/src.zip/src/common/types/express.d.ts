import type { TenantContext, AuthenticatedUser } from './tenant-context';
import type { AuditLogger } from '@common/middlewares/audit.middleware';

declare global {
  namespace Express {
    interface Request {
      requestId: string;
      tenantContext: TenantContext;
      user?: AuthenticatedUser; // set by auth.middleware (Module 4)
      audit: AuditLogger; // set by audit.middleware
    }
  }
}

export {};
