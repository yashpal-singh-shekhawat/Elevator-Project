// Phase 1: values are always { tenantId: 1, organizationId: 1 }, injected by
// tenant.middleware.ts from static config — never read directly by services.
// Phase 2: the same shape is populated by decoding JWT tenant claims instead.
// Because every repository method takes this as an explicit parameter (not a
// global/singleton), swapping the source requires no change below the middleware.
export interface TenantContext {
  tenantId: number;
  organizationId: number;
}

// Populated by auth.middleware once Module 4 (Auth) lands. Optional for now
// so infra code compiles before the auth module exists.
export interface AuthenticatedUser {
  id: number;
  tenantId: number;
  organizationId: number;
  roleId: number;
  roleCode: string;
  email: string;
  permissions: string[];
}
