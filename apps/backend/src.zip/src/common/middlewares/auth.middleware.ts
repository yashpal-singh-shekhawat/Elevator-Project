import { NextFunction, Request, Response } from 'express';
import { TokenExpiredError, JsonWebTokenError } from 'jsonwebtoken';
import { verifyAccessToken } from '@common/utils/jwt';
import { UnauthorizedError } from '@common/errors';

const AUTH_HEADER = 'authorization';
const BEARER_PREFIX = 'Bearer ';

/**
 * Verifies the access token from the `Authorization: Bearer <token>` header
 * and populates req.user. Mounted per-router (not globally in app.ts) so
 * public routes like /auth/login and /auth/refresh stay unauthenticated.
 *
 * Phase 2 note: once tenant resolution moves to JWT claims, this middleware
 * must run BEFORE tenantContextMiddleware on protected routes so
 * req.tenantContext can be derived from req.user.
 */
export function authenticate(req: Request, _res: Response, next: NextFunction): void {
  const header = req.header(AUTH_HEADER);

  if (!header || !header.startsWith(BEARER_PREFIX)) {
    next(new UnauthorizedError('Missing or malformed Authorization header'));
    return;
  }

  const token = header.slice(BEARER_PREFIX.length);

  try {
    const payload = verifyAccessToken(token);
    req.user = {
      id: payload.sub,
      tenantId: payload.tenantId,
      organizationId: payload.organizationId,
      roleId: payload.roleId,
      roleCode: payload.roleCode,
      email: payload.email,
      permissions: payload.permissions
    };
    next();
  } catch (err) {
    if (err instanceof TokenExpiredError) {
      next(new UnauthorizedError('Access token has expired'));
      return;
    }
    if (err instanceof JsonWebTokenError) {
      next(new UnauthorizedError('Invalid access token'));
      return;
    }
    next(new UnauthorizedError('Authentication failed'));
  }
}
