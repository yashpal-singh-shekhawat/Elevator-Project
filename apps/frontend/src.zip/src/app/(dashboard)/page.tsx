'use client';

import Link from 'next/link';
import { Wrench, ClipboardList } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

export default function DashboardHomePage() {
  const { user } = useAuth();

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="font-display text-2xl font-semibold tracking-tight">Welcome back, {user?.firstName}</h1>
        <p className="text-sm text-muted-foreground">{user?.roleName} · Installation &amp; AMC operations</p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Link href="/installation-projects">
          <Card className="transition-colors hover:border-primary/50">
            <CardHeader className="flex-row items-center gap-3 space-y-0">
              <div className="rounded-[var(--radius)] bg-accent p-2 text-accent-foreground">
                <Wrench className="h-4 w-4" strokeWidth={1.75} />
              </div>
              <div>
                <CardTitle>Installation Projects</CardTitle>
                <CardDescription>Track lift installations from survey to sign-off</CardDescription>
              </div>
            </CardHeader>
          </Card>
        </Link>

        <Link href="/amc-contracts">
          <Card className="transition-colors hover:border-primary/50">
            <CardHeader className="flex-row items-center gap-3 space-y-0">
              <div className="rounded-[var(--radius)] bg-accent p-2 text-accent-foreground">
                <ClipboardList className="h-4 w-4" strokeWidth={1.75} />
              </div>
              <div>
                <CardTitle>AMC Contracts</CardTitle>
                <CardDescription>Manage service contracts, schedules, and visits</CardDescription>
              </div>
            </CardHeader>
          </Card>
        </Link>
      </div>

      <p className="text-xs text-muted-foreground">
        Screens for each section above are built in Module 10 (Installation) and Module 11 (AMC).
      </p>
    </div>
  );
}
