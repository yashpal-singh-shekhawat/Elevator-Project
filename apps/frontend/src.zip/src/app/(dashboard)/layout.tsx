'use client';

import { useEffect } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { LayoutDashboard, Wrench, ClipboardList, Building2, ArrowUpDown, Database, Users, LogOut } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const NAV_ITEMS = [
  { href: '/', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/installation-projects', label: 'Installations', icon: Wrench },
  { href: '/amc-contracts', label: 'AMC', icon: ClipboardList },
  { href: '/customers', label: 'Customers', icon: Building2 },
  { href: '/lifts', label: 'Lifts', icon: ArrowUpDown },
  { href: '/master-data', label: 'Master Data', icon: Database },
  { href: '/users', label: 'Users', icon: Users }
] as const;

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { user, isLoading, logout } = useAuth();
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    if (!isLoading && !user) {
      router.replace('/login');
    }
  }, [isLoading, user, router]);

  if (isLoading || !user) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background text-sm text-muted-foreground">
        Loading…
      </div>
    );
  }

  return (
    <div className="flex min-h-screen">
      <aside className="flex w-60 shrink-0 flex-col border-r border-sidebar-border bg-sidebar text-sidebar-foreground">
        <div className="flex items-center gap-2 px-5 py-5">
          <div className="h-6 w-1.5 rounded-sm bg-sidebar-active" aria-hidden />
          <span className="font-display text-sm font-semibold tracking-tight text-white">Lift SaaS</span>
        </div>

        <nav className="flex flex-1 flex-col gap-0.5 px-3">
          {NAV_ITEMS.map((item) => {
            const isActive = pathname === item.href;
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  'flex items-center gap-2.5 rounded-[var(--radius)] px-3 py-2 text-sm transition-colors',
                  isActive
                    ? 'bg-sidebar-active text-sidebar-active-foreground font-medium'
                    : 'text-sidebar-foreground hover:bg-white/5 hover:text-white'
                )}
              >
                <Icon className="h-4 w-4" strokeWidth={1.75} />
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="border-t border-sidebar-border px-5 py-4">
          <p className="truncate text-xs font-mono text-sidebar-foreground/70">{user.email}</p>
          <p className="mb-3 truncate text-xs text-sidebar-foreground/50">{user.roleName}</p>
          <Button
            variant="ghost"
            size="sm"
            className="w-full justify-start gap-2 px-0 text-sidebar-foreground hover:bg-transparent hover:text-white"
            onClick={() => logout().then(() => router.replace('/login'))}
          >
            <LogOut className="h-3.5 w-3.5" /> Sign out
          </Button>
        </div>
      </aside>

      <main className="flex-1 overflow-auto bg-background">
        <div className="mx-auto max-w-6xl px-8 py-8">{children}</div>
      </main>
    </div>
  );
}
